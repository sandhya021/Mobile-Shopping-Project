 online-shopping


This is an online shopping project using Spring Boot,Spring web-flow, Spring Rest Services and Hibernate. 

## Requirements

For building and running the application you need:

- [JDK 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
- [Maven 3](https://maven.apache.org)

# Runnig this project


1.copy the link from gitub &  Clone this project https://github.com/sandhya021/ProjectFinal
2. create databases schema in mysql - **online_shopping_db**
3. edit **username** and **password** in **applicaton.properties** file
4. Run Project One time  or using eclipse IDE run as Java Application
5: load the tables in  database. insert data to product table  
6. Then Again run project using boot
7. create user by signup

## DONE BY 
1:HANUMANTHA REDDY 
2:POOJITHA UNNAM
3:ROSHINI MOHANKUMAR
4:SANDHYA LOKESH





